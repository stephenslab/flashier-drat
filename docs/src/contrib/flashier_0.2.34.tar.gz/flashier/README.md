# flashier

This package is in active development. The interface is likely to change from time to time.

Install using:

```devtools::install_github("willwerscheid/flashier", build_vignettes = TRUE)```.

The vignettes take around 2 minutes to build. Start with:

```vignette("intro", "flashier")```.

Then have a look at:

```vignette("advanced", "flashier")```.

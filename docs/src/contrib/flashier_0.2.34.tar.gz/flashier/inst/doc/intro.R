## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, collapse = TRUE, comment = "#>",
                      fig.width = 6, fig.height = 6, warning = FALSE)
library(flashier)
library(ggplot2)

## ----gtex.const---------------------------------------------------------------
data(gtex, gtex.colors)
gtex.const <- flash(gtex, greedy.Kmax = 5)

## ----gtex.output--------------------------------------------------------------
gtex.const$elbo

## ----plot.fn------------------------------------------------------------------
plot.factors <- function(fl) {
  vals <- ldf(fl)$F
  
  data <- reshape2::melt(vals)
  min.val <- min(0, min(vals))
  max.val <- max(0, max(vals))
  
  colnames(data) <- c("variable", "k", "value")
  data$k <- as.factor(data$k)
  ggplot(data, aes_string(x = "variable", y = "value", fill = "variable")) +
    geom_bar(stat = "identity", width = 0.6) +
    scale_fill_manual(values = gtex.colors) +
    scale_x_discrete(labels = NULL) +
    ylim(min.val, max.val) +
    theme_grey() +
    theme(
      legend.position = "right",
      legend.text = element_text(size = 6),
      legend.title = element_blank()
    ) +
    labs(y = "", x = "") +
    facet_wrap(~k, ncol = 2) +
    guides(fill = guide_legend(
      ncol = 1, 
      keyheight = 3.75 / 6, 
      keywidth = 3.75 / 15)
    )
}

plot.factors(gtex.const)

## ----gtex.byrow---------------------------------------------------------------
byrow.time <- system.time(
  gtex.byrow <- flash(gtex, greedy.Kmax = 5, var.type = 1, verbose = 0)
)
c(const.elbo = gtex.const$elbo, byrow.elbo = gtex.byrow$elbo)

## ----plot.byrow---------------------------------------------------------------
plot.factors(gtex.byrow)

## ----gtex.kronecker-----------------------------------------------------------
kronecker.time <- system.time(
  gtex.kronecker <- flash(gtex, greedy.Kmax = 5, var.type = c(1, 2), verbose = 0)
)
c(const.elbo = gtex.const$elbo, byrow.elbo = gtex.byrow$elbo, kron.elbo = gtex.kronecker$elbo)

## ----timing-------------------------------------------------------------------
c(byrow = byrow.time[3], kron = kronecker.time[3])

## ----gtex.byrow.plus.1--------------------------------------------------------
gtex.byrow.plus.1 <- flash(gtex, S = 1, greedy.Kmax = 5, var.type = 1, verbose = 0)
c(byrow.elbo = gtex.byrow$elbo, byrow.p1.elbo = gtex.byrow.plus.1$elbo)

## ----gtex.normalmix-----------------------------------------------------------
pn.time <- system.time(
  gtex.pn <- flash(
    gtex, 
    greedy.Kmax = 5, 
    verbose = 0
  )
)
normalmix.time <- system.time(
  gtex.normalmix <- flash(
    gtex, 
    greedy.Kmax = 5, 
    ebnm.fn = ebnm::ebnm_normal_scale_mixture, 
    verbose = 0
  )
)
unimix.time <- system.time(
  gtex.unimix <- flash(
    gtex, 
    greedy.Kmax = 5, 
    ebnm.fn = ebnm::ebnm_unimodal_symmetric, 
    verbose = 0
  )
)
c(pn.elbo = gtex.pn$elbo, smn.elbo = gtex.normalmix$elbo, symmuni.elbo = gtex.unimix$elbo)
c(pn = pn.time[3], smn = normalmix.time[3], symmuni = unimix.time[3])

## ----gtex.w.mean--------------------------------------------------------------
gtex.w.mean <- flash(
  gtex, 
  greedy.Kmax = 1,
  ebnm.fn = as.ebnm.fn(prior_family = "normal", mode = "estimate"),
  verbose = 0
)

## ----gtex.nn------------------------------------------------------------------
gtex.diff.ebnm <- flash(
  gtex, 
  greedy.Kmax = 5, 
  ebnm.fn = c(ebnm::ebnm_normal, ebnm::ebnm_unimodal_symmetric),
  verbose = 0
)

## ----backfit------------------------------------------------------------------
bf.time <- system.time(
  gtex.bf <- flash(
    gtex, 
    greedy.Kmax = 5, 
    var.type = 1, 
    backfit = TRUE, 
    verbose = 0
  )
)
c(greedy.elbo = gtex.byrow$elbo, bf.elbo = gtex.bf$elbo)
c(greedy = byrow.time[3], bf = bf.time[3])

plot.factors(gtex.bf)

## ----final.bf.ci--------------------------------------------------------------
# Use returned sampler to sample from posterior.
samp <- gtex.bf$sampler(nsamp = 200)
# Only keep factor 3.
factor3.samp <- lapply(samp, function(x) x[[2]][, 3])
# Normalize the loadings.
factor3.samp <- sapply(factor3.samp, function(x) x / sqrt(sum(x^2)))
# Get 95% confidence intervals.
factor3.ci <- apply(factor3.samp, 1, quantile, c(0.025, 0.975))

# Put data into data frame and plot.
vals <- ldf(gtex.bf)$F[, 3]
df <- data.frame(
  variable = colnames(gtex), 
  value = vals, 
  lower.ci = factor3.ci[1, ], 
  upper.ci = factor3.ci[2, ]
)
ggplot(df, aes_string(x = "variable", y = "value", fill = "variable")) +
  geom_bar(stat = "identity", width = 0.6, position = position_dodge()) +
  geom_errorbar(
    aes(ymin = lower.ci, ymax = upper.ci), 
    width = .4,
    position = position_dodge(.9)
  ) +
  scale_fill_manual(values = gtex.colors) +
  scale_x_discrete(labels = NULL) +
  ylim(-1, 0.2) +
  theme_grey() +
  theme(
    legend.position="right",
    legend.text = element_text(size = 6),
    legend.title = element_blank()
  ) +
  labs(y = "", x = "") +
  guides(fill = guide_legend(
    ncol = 1, 
    keyheight = 3.75 / 6, 
    keywidth = 3.75 / 15)
  )


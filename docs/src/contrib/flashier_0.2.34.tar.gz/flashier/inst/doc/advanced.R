## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, collapse = TRUE, comment = "#>",
                      fig.width = 6, fig.height = 6, warning = FALSE)
library(flashier)
library(ggplot2)

## ----adv_interface------------------------------------------------------------
# Basic interface:
gtex.bf <- flash(
    gtex,
    greedy.Kmax = 5,
    var.type = 1,
    backfit = TRUE,
    verbose = 0
  )

# Pipeable interface:
bf.time <- system.time(
  gtex.bf <- flash.init(gtex, var.type = 1) %>%
    flash.set.verbose(verbose = 0) %>%
    flash.add.greedy(Kmax = 5) %>%
    flash.backfit() %>%
    flash.nullcheck()
)

## ----plot.fn------------------------------------------------------------------
data(gtex, gtex.colors)

plot.factors <- function(fl) {
  vals <- ldf(fl)$F
  
  data <- reshape2::melt(vals)
  min.val <- min(0, min(vals))
  max.val <- max(0, max(vals))
  
  colnames(data) <- c("variable", "k", "value")
  data$k <- as.factor(data$k)
  ggplot(data, aes_string(x = "variable", y = "value", fill = "variable")) +
    geom_bar(stat = "identity", width = 0.6) +
    scale_fill_manual(values = gtex.colors) +
    scale_x_discrete(labels = NULL) +
    ylim(min.val, max.val) +
    theme_grey() +
    theme(
      legend.position = "right",
      legend.text = element_text(size = 6),
      legend.title = element_blank()
    ) +
    labs(y = "", x = "") +
    facet_wrap(~k, ncol = 2) +
    guides(fill = guide_legend(
      ncol = 1, 
      keyheight = 3.75 / 6, 
      keywidth = 3.75 / 15)
    )
}

## ----no.extrap----------------------------------------------------------------
no.extrapolate.time <- system.time(
  gtex.no.extrapolate <- flash.init(gtex, var.type = 1) %>%
    flash.set.verbose(verbose = 0) %>%
    flash.add.greedy(Kmax = 5) %>%
    flash.backfit(extrapolate = FALSE) %>%
    flash.nullcheck()
)
c(bf.elbo = gtex.bf$elbo, no.extrapolate.elbo = gtex.no.extrapolate$elbo)
c(bf = bf.time[3], no.extrapolate = no.extrapolate.time[3])

## ----init.factors-------------------------------------------------------------
gtex.svd <- flash.init(gtex, var.type = 1) %>%
  flash.init.factors(svd(gtex, nu = 5, nv = 5)) %>%
  flash.backfit(verbose = 0)
c(svd.bf.elbo = gtex.svd$elbo, greedy.bf.elbo = gtex.bf$elbo)

plot.factors(gtex.svd)

## ----fix.mean-----------------------------------------------------------------
ones <- matrix(1, nrow = ncol(gtex), ncol = 1)
init.loadings <- (gtex %*% ones) / sum(ones)

gtex.fix.mean <- flash.init(gtex, var.type = 1) %>%
  flash.set.verbose(0) %>%
  flash.init.factors(list(init.loadings, ones)) %>%
  flash.fix.factors(kset = 1, mode = 2) %>%
  flash.add.greedy(Kmax = 4) %>%
  flash.backfit()

plot.factors(gtex.fix.mean)

## ----snmf---------------------------------------------------------------------
gtex.snmf <- flash.init(gtex, var.type = 1) %>%
  flash.set.verbose(0) %>%
  flash.add.greedy(
    Kmax = 5,
    ebnm.fn = c(ebnm::ebnm_point_normal, ebnm::ebnm_unimodal_nonnegative),
    init.fn = function(f) init.fn.default(f, dim.signs = c(0, 1))
  ) %>%
  flash.backfit()

plot.factors(gtex.snmf)

## ----fixed.sprs---------------------------------------------------------------
tissues <- colnames(gtex)
fixed.factors <- 1L * cbind(
  rep(TRUE, length(tissues)),
  grepl("Brain", tissues),
  grepl("Whole|Spleen|Lung|EBV", tissues),
  grepl("Heart|Muscle", tissues),
  grepl("Artery|Esophagus", tissues)
)
init.loadings <- (gtex %*% fixed.factors) %*% solve(crossprod(fixed.factors))

gtex.fixed.sprs <- flash.init(gtex, var.type = 1) %>%
  flash.set.verbose(0) %>%
  flash.init.factors(list(init.loadings, fixed.factors)) %>%
  flash.fix.factors(kset = 1:5, mode = 2, is.fixed = (fixed.factors == 0)) %>%
  flash.backfit()

plot.factors(gtex.fixed.sprs)

## ----conv.crit----------------------------------------------------------------
gtex.conv.crit <- flash.init(gtex, var.type = 1) %>%
  flash.set.verbose(
    disp.fns = c(display.elbo, display.F.max.chg),
    colnames = c("ELBO", "Max.Chg.Factors"),
    colwidths = c(18, 18)
  ) %>%
  flash.init.factors(svd(gtex, nu = 5, nv = 5)) %>%
  flash.backfit(
    conv.crit.fn = conv.crit.factors,
    tol = .001
  )

## ----plot.history, eval = FALSE-----------------------------------------------
#  sink("zz.tsv")
#  tmp <- flash.init(gtex, var.type = 1) %>%
#    flash.set.verbose(-1) %>%
#    flash.init.factors(svd(gtex, nu = 5, nv = 5)) %>%
#    flash.backfit()
#  progress.bf <- read.delim("zz.tsv")
#  sink()
#  
#  sink("zz.tsv")
#  tmp <- flash.init(gtex, var.type = 1) %>%
#    flash.set.verbose(-1) %>%
#    flash.init.factors(svd(gtex, nu = 5, nv = 5)) %>%
#    flash.backfit(extrapolate = FALSE)
#  progress.no.extrapolate <- read.delim("zz.tsv")
#  sink()
#  
#  rm(tmp)
#  file.remove("zz.tsv")
#  
#  progress.bf <- progress.bf %>%
#    mutate(Extrapolate = TRUE) %>%
#    select(Iter, ELBO, Extrapolate)
#  
#  progress.no.extrapolate <- progress.no.extrapolate %>%
#    group_by(Iter) %>%
#    summarize(ELBO = max(ELBO, na.rm = TRUE)) %>%
#    ungroup() %>%
#    mutate(Extrapolate = FALSE)
#  
#  tib <- progress.bf %>%
#    bind_rows(progress.no.extrapolate)
#  
#  ggplot(tib, aes(x = Iter, y = ELBO, col = Extrapolate)) +
#    geom_line() +
#    theme_minimal()

## ----custom-------------------------------------------------------------------
disp.sparsity <- function(new, old, k, f.idx) {
  g <- ff.g(new, n = 2) # setting n = 2 gets g_f (n = 1 would get g_\ell)
  return(g[[f.idx]]$pi[1])
}
disp.sprs2 <- function(new, old, k) disp.sparsity(new, old, k, 2)
disp.sprs3 <- function(new, old, k) disp.sparsity(new, old, k, 3)
disp.sprs4 <- function(new, old, k) disp.sparsity(new, old, k, 4)
disp.sprs5 <- function(new, old, k) disp.sparsity(new, old, k, 5)

gtex.sprs <- flash.init(gtex, var.type = 1) %>%
  flash.set.verbose(
    disp.fns = c(display.elbo, disp.sprs2, disp.sprs3, disp.sprs4, disp.sprs5),
    colnames = c("ELBO", paste0("Sparsity (", 2:5, ")")),
    colwidths = rep(14, 5)
  ) %>%
  flash.init.factors(svd(gtex, nu = 5, nv = 5)) %>%
  flash.backfit()

## ----custom.ebnm--------------------------------------------------------------
ebnm.custom <- function(x, s, g_init, fix_g, output) {
  if (!fix_g) {
    # Parameters are mixture wt on pointmass and mean/sd of normal:
    neg.llik <- function(par) {
      g <- ashr::normalmix(c(par[1], 1 - par[1]), c(0, par[2]), c(0, par[3]))
      ebnm.res <- ebnm::ebnm_normal_scale_mixture(x, s, g_init = g, fix_g = FALSE)
      return(-ebnm.res$log_likelihood)
    }
    
    opt.res <- optim(
      c(0.5, 0, 1), 
      neg.llik, 
      method = "L-BFGS-B", 
      lower = c(0, -Inf, 0.01), 
      upper = c(1, Inf, Inf)
    )
    
    par <- opt.res$par
    g_init <- ashr::normalmix(c(par[1], 1 - par[1]), c(0, par[2]), c(0, par[3]))
  }
  
  ebnm.res <- ebnm::ebnm_normal_scale_mixture(
    x, 
    s, 
    g_init = g_init, 
    fix_g = fix_g, 
    output = output
  )
  
  return(ebnm.res)
}

gtex.custom <- flash.init(gtex, var.type = 1) %>%
  flash.set.verbose(0) %>%
  flash.add.greedy(
    Kmax = 3,
    ebnm.fn = c(ebnm::ebnm_point_normal, ebnm.custom)
  )

gtex.custom$F.ghat

